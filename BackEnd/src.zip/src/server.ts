import { IAwsAccount } from "./models/awsAccount";

const AwsAccount : IAwsAccount = {
    AwsAccountId: '821680281153',
    Namespace: 'default',
    AuthorizedResourceArns: ['arn:aws:quicksight:us-east-1:821680281153:dashboard/61dbe920-96a3-400c-b8fa-d90cea4438f1'],
    AllowedDomains: ['http://localhost:3000'],
    ExperienceConfiguration: {
        DashboardVisual:{
            InitialDashboardVisualId:{
                DashboardId: '61dbe920-96a3-400c-b8fa-d90cea4438f1',
                SheetId: '61dbe920-96a3-400c-b8fa-d90cea4438f1_6df3cb25-6dba-46ce-bece-c5c794399c7e',
                VisualId: '61dbe920-96a3-400c-b8fa-d90cea4438f1_aa05c697-8bc5-4d13-9fde-bdaaf88b9ee5',
            }
        }
    },
    SessionLifetimeInMinutes: 600,
    SessionTags:[{
        Key: 'test',
        Value: 'Medio'
    }]
}

const AWS = require('aws-sdk');
const https = require('https');
    var quicksightClient = new AWS.Service({
        apiConfig: require('./quicksight-2018-04-01.min.json'),
        region: 'us-east-1',
    });

    quicksightClient.generateEmbedUrlForAnonymousUser({
        'AwsAccountId': AwsAccount.AwsAccountId,
        'Namespace' : AwsAccount.Namespace,
        'AuthorizedResourceArns': AwsAccount.AuthorizedResourceArns,
        'AllowedDomains': AwsAccount.AllowedDomains,
        'ExperienceConfiguration': AwsAccount.ExperienceConfiguration,
        'SessionTags': AwsAccount.SessionTags,
        'SessionLifetimeInMinutes': AwsAccount.SessionLifetimeInMinutes

        }, function(err: any, data: any) {
        console.log('Errors: ');
        console.log(err);
        console.log('Response: ');
        console.log(data);
    });

const express = require('express');


const app = express();
const port = 3000;

app.get('/', (req: any, res: {
    sendFile(arg0: string): unknown; send: (arg0: string) => void; 
}) => {
    res.sendFile(__dirname + "/index.html");
});

app.listen(port, () => {
  console.log(`[server]: Server is running at http://localhost:${port}`);
});


