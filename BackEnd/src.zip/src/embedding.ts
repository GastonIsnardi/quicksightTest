import { EmbedConsole, EmbedDashboard, EmbedQSearch, EmbedVisual, ExperienceFrameMetadata, SimpleChangeEvent } from "amazon-quicksight-embedding-sdk/dist/types";

export type CreateEmbeddingContext = (frameOptions?: CreateEmbeddingContextFrameOptions) => Promise<EmbeddingContext>;

export type SimpleChangeEventHandler = (message: SimpleChangeEvent, metadata?: ExperienceFrameMetadata) => void;

export type CreateEmbeddingContextFrameOptions = {
    onChange?: SimpleChangeEventHandler;
};

export type EmbeddingContext = {
    embedDashboard: EmbedDashboard;
    embedVisual: EmbedVisual;
    embedQSearchBar: EmbedQSearch;
    embedConsole: EmbedConsole;
};